

pip install ultralytics

runs/detect/train/weights/best.pt



Để tạo label cho ảnh trong thư mục images/train theo định dạng YOLO


pip install labelImg
labelImg
Mở thư mục images/train trong LabelImg.

Chọn định dạng lưu là YOLO (bên phải giao diện).

Gán nhãn cho từng ảnh bằng cách:

Vẽ bounding box quanh đối tượng.
Gán tên lớp (ví dụ: fish, floating_object).
Nhấn Save để tạo file .txt tương ứng.
LabelImg sẽ tự động tạo thư mục labels/train chứa các file .txt.