from ultralytics import YOLO

# Tạo mô hình YOLOv8 mới (hoặc dùng mô hình có sẵn để fine-tune)
model = YOLO("yolov8n.pt")  # hoặc yolov8s.pt, yolov8m.pt tùy theo tài nguyên

# Huấn luyện
model.train(data="data.yaml", epochs=50, imgsz=640, batch=16)
