import React, { useState } from 'react';
import { Icon, TabButton } from './components/UI';
import { ConfirmModal, AddProductModal, EmployeeModal, AddStoreModal, DistributeModal } from './components/Modals';
import { useAppState } from './hooks/useAppState';

// Pages
import AdminDashboard from './pages/AdminDashboard';
import AdminStores from './pages/AdminStores';
import AdminWarehouse from './pages/AdminWarehouse';
import AdminStaffGlobal from './pages/AdminStaffGlobal';
import AdminHistory from './pages/AdminHistory';
import StoreDetail from './pages/StoreDetail';

export default function App() {
    const state = useAppState();
    const {
        user, stores, globalProducts, warehouseTransactions,
        activeTab, selectedStore, storeSubTab, showModal, pendingAction,
        editingEmployee, toast, showUserMenu, searchTerm, historyFilter,
        currentStore, allEmployees, totalValue,
        setActiveTab, setSelectedStore, setStoreSubTab, setShowModal,
        setPendingAction, setEditingEmployee, setShowUserMenu,
        setSearchTerm, setHistoryFilter,
        handleLogin, handleLogout, handleSaveEmployee, handleDeleteEmployee,
        handleSaveGlobalProduct, handleImportToWarehouse, handleDistribute,
        handleAddStore, handleDeleteStore, handleSellProduct,
        getProductInfo,
    } = state;

    const [loginForm, setLoginForm] = useState({ username: '', password: '' });
    const [loginError, setLoginError] = useState('');

    const onLogin = (e) => {
        e.preventDefault();
        const err = handleLogin(loginForm);
        if (err) setLoginError(err);
    };

    // ==================== LOGIN ====================
    if (!user) {
        return (
            <div className="min-h-screen bg-slate-50 flex items-center justify-center p-6">
                <div className="w-full max-w-[380px] bg-white rounded-[32px] shadow-2xl p-10 text-center">
                    <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-blue-50 text-blue-600 mb-6"><Icon name="package" size={32} /></div>
                    <h1 className="text-2xl font-black text-slate-900 tracking-tight mb-2 uppercase">ĐĂNG NHẬP</h1>
                    <p className="text-slate-400 text-sm mb-8 font-medium leading-relaxed">Hệ thống quản lý chuỗi hợp nhất<br/>v2.5 Professional</p>
                    <form onSubmit={onLogin} className="space-y-4">
                        {loginError && <div className="bg-rose-50 text-rose-600 p-4 rounded-xl text-xs font-bold border border-rose-100">{loginError}</div>}
                        <input type="text" required className="w-full px-5 py-4 bg-slate-50 border border-slate-100 rounded-2xl outline-none focus:ring-2 focus:ring-blue-500 font-bold" placeholder="Username" value={loginForm.username} onChange={e => setLoginForm({...loginForm, username: e.target.value})} />
                        <input type="password" required className="w-full px-5 py-4 bg-slate-50 border border-slate-100 rounded-2xl outline-none focus:ring-2 focus:ring-blue-500 font-bold" placeholder="Password" value={loginForm.password} onChange={e => setLoginForm({...loginForm, password: e.target.value})} />
                        <button className="w-full bg-blue-600 text-white py-5 rounded-2xl font-black shadow-lg hover:bg-blue-700 transition-all uppercase text-xs tracking-widest mt-4">Vào hệ thống</button>
                    </form>
                </div>
            </div>
        );
    }

    // ==================== MAIN LAYOUT ====================
    return (
        <div className="min-h-screen flex flex-col">
            {/* Header */}
            <header className="bg-white border-b sticky top-0 z-50 h-20 px-8 flex items-center justify-between shadow-sm">
                <div className="flex items-center space-x-6 lg:space-x-10">
                    <div className="flex items-center space-x-3 cursor-pointer group" onClick={() => user.role === 'admin' && setActiveTab('dashboard')}>
                        <div className="bg-blue-600 p-2.5 rounded-xl shadow-lg group-hover:scale-105 transition-transform"><Icon name="package" size={22} className="text-white" /></div>
                        <h1 className="text-xl font-black tracking-tighter text-slate-900 uppercase hidden sm:block">ChainFlow</h1>
                    </div>
                    <nav className="flex items-center space-x-1 h-20 overflow-x-auto no-scrollbar">
                        {user.role === 'admin' ? (
                            <>
                                <TabButton active={activeTab === 'dashboard'} onClick={() => {setActiveTab('dashboard'); setSelectedStore(null)}} label="Tổng quan" icon="layout-dashboard" />
                                <TabButton active={activeTab === 'stores'} onClick={() => {setActiveTab('stores'); setSelectedStore(null)}} label="Chi nhánh" icon="store" />
                                <TabButton active={activeTab === 'warehouse'} onClick={() => {setActiveTab('warehouse'); setSelectedStore(null)}} label="Kho tổng" icon="warehouse" />
                                <TabButton active={activeTab === 'staff-global'} onClick={() => {setActiveTab('staff-global'); setSelectedStore(null)}} label="Nhân sự" icon="users" />
                                <TabButton active={activeTab === 'history'} onClick={() => {setActiveTab('history'); setSelectedStore(null)}} label="Lịch sử" icon="history" />
                            </>
                        ) : (
                            <TabButton active={activeTab === 'my-store'} onClick={() => setActiveTab('my-store')} label="Chi nhánh của tôi" icon="store" />
                        )}
                    </nav>
                </div>
                <div className="relative">
                    <button onClick={() => setShowUserMenu(!showUserMenu)} className="flex items-center space-x-3 bg-slate-50 p-1.5 pr-4 rounded-2xl border hover:bg-slate-100 transition-all">
                        <div className="w-10 h-10 rounded-xl bg-blue-600 flex items-center justify-center text-white font-black text-sm uppercase">{user.name.charAt(0)}</div>
                        <div className="text-left hidden sm:block leading-none mr-2"><p className="text-xs font-black text-slate-900 leading-none">{user.name}</p><p className="text-[10px] font-bold text-slate-400 uppercase mt-1 leading-none">{user.role === 'admin' ? 'Hệ thống' : 'Chi nhánh'}</p></div>
                        <Icon name="chevron-down" size={14} className="text-slate-300" />
                    </button>
                    {showUserMenu && (
                        <div className="absolute right-0 top-full mt-2 w-48 bg-white rounded-3xl shadow-2xl border border-slate-100 p-2 z-[60] overflow-hidden animate-in slide-in-from-top-2">
                            <button onClick={handleLogout} className="w-full flex items-center space-x-3 px-4 py-4 text-xs font-black text-rose-500 hover:bg-rose-50 rounded-2xl transition-all uppercase tracking-widest"><Icon name="log-out" size={16}/> <span>Đăng xuất</span></button>
                        </div>
                    )}
                </div>
            </header>

            {/* Main Content */}
            <main className="flex-1 p-8 max-w-[1400px] mx-auto w-full">
                {toast && <div className="fixed bottom-8 right-8 z-[100] bg-slate-900 text-white px-6 py-4 rounded-3xl shadow-2xl flex items-center space-x-4 animate-in slide-in-from-right"><Icon name="check-circle-2" size={16} className="text-emerald-400"/><p className="text-sm font-bold">{toast}</p></div>}

                {/* Admin Pages */}
                {user.role === 'admin' && activeTab === 'dashboard' && !selectedStore && (
                    <AdminDashboard stores={stores} globalProducts={globalProducts} allEmployees={allEmployees} setSelectedStore={setSelectedStore} setActiveTab={setActiveTab} />
                )}

                {user.role === 'admin' && activeTab === 'staff-global' && (
                    <AdminStaffGlobal allEmployees={allEmployees} stores={stores} searchTerm={searchTerm} setSearchTerm={setSearchTerm} setSelectedStore={setSelectedStore} setActiveTab={setActiveTab} setStoreSubTab={setStoreSubTab} setEditingEmployee={setEditingEmployee} setShowModal={setShowModal} handleDeleteEmployee={handleDeleteEmployee} />
                )}

                {user.role === 'admin' && activeTab === 'stores' && !selectedStore && (
                    <AdminStores stores={stores} setSelectedStore={setSelectedStore} setShowModal={setShowModal} handleDeleteStore={handleDeleteStore} />
                )}

                {user.role === 'admin' && activeTab === 'warehouse' && (
                    <AdminWarehouse globalProducts={globalProducts} totalValue={totalValue} setShowModal={setShowModal} handleImportToWarehouse={handleImportToWarehouse} />
                )}

                {user.role === 'admin' && activeTab === 'history' && (
                    <AdminHistory warehouseTransactions={warehouseTransactions} historyFilter={historyFilter} setHistoryFilter={setHistoryFilter} />
                )}

                {/* Store Detail — shared by admin (selected store) and staff (my-store) */}
                {currentStore && (activeTab === 'my-store' || selectedStore) && activeTab !== 'staff-global' && activeTab !== 'history' && (
                    <StoreDetail currentStore={currentStore} user={user} storeSubTab={storeSubTab} setStoreSubTab={setStoreSubTab} setSelectedStore={setSelectedStore} setEditingEmployee={setEditingEmployee} setShowModal={setShowModal} handleSellProduct={handleSellProduct} handleDeleteEmployee={handleDeleteEmployee} getProductInfo={getProductInfo} />
                )}
            </main>

            {/* Modals */}
            {showModal === 'confirmPopup' && <ConfirmModal pendingAction={pendingAction} setShowModal={setShowModal} setPendingAction={setPendingAction} />}
            {showModal === 'addGlobalProduct' && <AddProductModal setShowModal={setShowModal} handleSaveGlobalProduct={handleSaveGlobalProduct} />}
            {(showModal === 'addEmployee' || showModal === 'editEmployee') && <EmployeeModal showModal={showModal} setShowModal={setShowModal} editingEmployee={editingEmployee} setEditingEmployee={setEditingEmployee} handleSaveEmployee={handleSaveEmployee} currentStoreId={currentStore?.id} />}
            {showModal === 'addStore' && <AddStoreModal setShowModal={setShowModal} handleAddStore={handleAddStore} />}
            {showModal === 'distribute' && <DistributeModal setShowModal={setShowModal} stores={stores} globalProducts={globalProducts} currentStore={currentStore} handleDistribute={handleDistribute} />}
        </div>
    );
}
