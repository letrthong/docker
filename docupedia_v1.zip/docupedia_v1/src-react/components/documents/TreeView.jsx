import { useState, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  ChevronRight, 
  ChevronDown, 
  FileText, 
  Folder, 
  FolderOpen,
  Plus,
  MoreHorizontal,
  Trash2,
  Edit2
} from 'lucide-react';
import { useProject } from '../../contexts/ProjectContext';
import { useToast } from '../../contexts/ToastContext';
import { Button, Modal, Input } from '../common';

function TreeNode({ 
  node, 
  level = 0, 
  onSelectDocument, 
  selectedId,
  nodes,
  onCreateDocument,
  onCreateFolder,
  onDelete,
  onRename
}) {
  const [expanded, setExpanded] = useState(true);
  const [showMenu, setShowMenu] = useState(false);
  
  const isFolder = node.type === 'folder';
  const isSelected = node.id === selectedId;
  const children = node.children?.map(id => nodes[id]).filter(Boolean) || [];

  const handleClick = () => {
    if (isFolder) {
      setExpanded(!expanded);
    } else {
      onSelectDocument(node.id);
    }
  };

  return (
    <div>
      <div
        className={`group flex items-center gap-2 py-2 px-2 rounded-lg cursor-pointer text-sm transition-all ${
          isSelected
            ? 'bg-emerald-100 dark:bg-emerald-900/30 text-emerald-700 dark:text-emerald-300 font-medium'
            : 'hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-600 dark:text-slate-400'
        }`}
        style={{ paddingLeft: `${level * 16 + 8}px` }}
        onClick={handleClick}
      >
        {/* Expand icon for folders */}
        {isFolder && (
          <span className="w-4 h-4 flex items-center justify-center text-slate-400">
            {expanded ? (
              <ChevronDown className="w-4 h-4" />
            ) : (
              <ChevronRight className="w-4 h-4" />
            )}
          </span>
        )}
        {!isFolder && <span className="w-4" />}

        {/* Icon - larger and more visible */}
        {isFolder ? (
          expanded ? (
            <FolderOpen className="w-5 h-5 text-amber-500 flex-shrink-0" />
          ) : (
            <Folder className="w-5 h-5 text-amber-500 flex-shrink-0" />
          )
        ) : (
          <FileText className="w-5 h-5 text-emerald-500 flex-shrink-0" />
        )}

        {/* Title */}
        <span className="flex-1 truncate">{node.title}</span>

        {/* Actions */}
        <div className="relative opacity-0 group-hover:opacity-100 transition-opacity">
          <button
            onClick={(e) => {
              e.stopPropagation();
              setShowMenu(!showMenu);
            }}
            className="p-1 hover:bg-slate-200 dark:hover:bg-slate-700 rounded-md transition"
          >
            <MoreHorizontal className="w-4 h-4 text-slate-400" />
          </button>
          
          {showMenu && (
            <div 
              className="absolute right-0 top-full mt-1 w-44 bg-white dark:bg-slate-900 rounded-xl shadow-2xl border border-slate-200 dark:border-slate-800 py-1 z-20"
              onClick={(e) => e.stopPropagation()}
            >
              {isFolder && (
                <>
                  <button
                    onClick={() => {
                      setShowMenu(false);
                      onCreateDocument(node.id);
                    }}
                    className="w-full flex items-center gap-2.5 px-3 py-2 text-sm text-slate-700 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800 transition"
                  >
                    <FileText className="w-4 h-4 text-emerald-500" />
                    Tài liệu mới
                  </button>
                  <button
                    onClick={() => {
                      setShowMenu(false);
                      onCreateFolder(node.id);
                    }}
                    className="w-full flex items-center gap-2.5 px-3 py-2 text-sm text-slate-700 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800 transition"
                  >
                    <Folder className="w-4 h-4 text-amber-500" />
                    Thư mục mới
                  </button>
                  <div className="my-1 border-t border-slate-100 dark:border-slate-800" />
                </>
              )}
              <button
                onClick={() => {
                  setShowMenu(false);
                  onRename(node);
                }}
                className="w-full flex items-center gap-2.5 px-3 py-2 text-sm text-slate-700 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800 transition"
              >
                <Edit2 className="w-4 h-4 text-slate-400" />
                Đổi tên
              </button>
              <button
                onClick={() => {
                  setShowMenu(false);
                  onDelete(node);
                }}
                className="w-full flex items-center gap-2.5 px-3 py-2 text-sm text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/30 transition"
              >
                <Trash2 className="w-4 h-4" />
                Xóa
              </button>
            </div>
          )}
        </div>
      </div>

      {/* Children */}
      {isFolder && expanded && children.length > 0 && (
        <div>
          {children.map((child) => (
            <TreeNode
              key={child.id}
              node={child}
              level={level + 1}
              onSelectDocument={onSelectDocument}
              selectedId={selectedId}
              nodes={nodes}
              onCreateDocument={onCreateDocument}
              onCreateFolder={onCreateFolder}
              onDelete={onDelete}
              onRename={onRename}
            />
          ))}
        </div>
      )}
    </div>
  );
}

function TreeView() {
  const navigate = useNavigate();
  const { tree, currentProject, currentDocument, loadDocument, createDocument, createFolder, deleteDocument, deleteFolder, hasPermission } = useProject();
  const { success, error } = useToast();
  
  const [newDocModal, setNewDocModal] = useState({ open: false, parentId: 'root' });
  const [newFolderModal, setNewFolderModal] = useState({ open: false, parentId: 'root' });
  const [deleteModal, setDeleteModal] = useState({ open: false, node: null });
  const [renameModal, setRenameModal] = useState({ open: false, node: null });
  const [newTitle, setNewTitle] = useState('');

  const canCreate = hasPermission('create');
  const canDelete = hasPermission('delete');
  const canEdit = hasPermission('edit');

  const handleSelectDocument = (docId) => {
    loadDocument(docId);
  };

  const handleCreateDocument = async () => {
    if (!newTitle.trim()) return;
    
    const result = await createDocument({
      title: newTitle.trim(),
      parent_id: newDocModal.parentId
    });
    
    if (result.success) {
      success('Tạo tài liệu thành công');
      setNewDocModal({ open: false, parentId: 'root' });
      setNewTitle('');
      // Auto-select new document
      if (result.data?.id) {
        loadDocument(result.data.id);
      }
    } else {
      error(result.error || 'Không thể tạo tài liệu');
    }
  };

  const handleCreateFolder = async () => {
    if (!newTitle.trim()) return;
    
    const result = await createFolder({
      title: newTitle.trim(),
      parent_id: newFolderModal.parentId
    });
    
    if (result.success) {
      success('Tạo thư mục thành công');
      setNewFolderModal({ open: false, parentId: 'root' });
      setNewTitle('');
    } else {
      error(result.error || 'Không thể tạo thư mục');
    }
  };

  const handleDelete = async () => {
    const node = deleteModal.node;
    if (!node) return;
    
    const result = node.type === 'folder' 
      ? await deleteFolder(node.id)
      : await deleteDocument(node.id);
    
    if (result.success) {
      success(`Đã xóa ${node.type === 'folder' ? 'thư mục' : 'tài liệu'}`);
      setDeleteModal({ open: false, node: null });
    } else {
      error(result.error || 'Không thể xóa');
    }
  };

  if (!tree) {
    return (
      <div className="flex items-center justify-center text-slate-400 py-4 gap-2">
        <div className="animate-spin rounded-full h-4 w-4 border-2 border-emerald-200 border-t-emerald-600" />
        <span className="text-sm">Đang tải...</span>
      </div>
    );
  }

  const rootChildren = tree.root?.children?.map(id => tree.nodes?.[id]).filter(Boolean) || [];

  return (
    <div>
      {/* Root level actions */}
      {canCreate && (
        <div className="flex gap-2 mb-3">
          <button
            onClick={() => {
              setNewTitle('');
              setNewDocModal({ open: true, parentId: 'root' });
            }}
            className="flex-1 flex items-center justify-center gap-1.5 px-3 py-2 text-xs font-semibold bg-emerald-50 dark:bg-emerald-950/30 text-emerald-600 dark:text-emerald-400 rounded-xl hover:bg-emerald-100 dark:hover:bg-emerald-950/50 transition"
          >
            <Plus className="w-3.5 h-3.5" />
            Tài liệu
          </button>
          <button
            onClick={() => {
              setNewTitle('');
              setNewFolderModal({ open: true, parentId: 'root' });
            }}
            className="flex-1 flex items-center justify-center gap-1.5 px-3 py-2 text-xs font-semibold bg-amber-50 dark:bg-amber-950/30 text-amber-600 dark:text-amber-400 rounded-xl hover:bg-amber-100 dark:hover:bg-amber-950/50 transition"
          >
            <Folder className="w-3.5 h-3.5" />
            Thư mục
          </button>
        </div>
      )}

      {/* Tree */}
      {rootChildren.length > 0 ? (
        rootChildren.map((node) => (
          <TreeNode
            key={node.id}
            node={node}
            level={0}
            onSelectDocument={handleSelectDocument}
            selectedId={currentDocument?.id}
            nodes={tree.nodes || {}}
            onCreateDocument={(parentId) => {
              if (canCreate) {
                setNewTitle('');
                setNewDocModal({ open: true, parentId });
              }
            }}
            onCreateFolder={(parentId) => {
              if (canCreate) {
                setNewTitle('');
                setNewFolderModal({ open: true, parentId });
              }
            }}
            onDelete={(node) => {
              if (canDelete) {
                setDeleteModal({ open: true, node });
              }
            }}
            onRename={(node) => {
              if (canEdit) {
                setNewTitle(node.title);
                setRenameModal({ open: true, node });
              }
            }}
          />
        ))
      ) : (
        <div className="text-center py-6">
          <div className="w-12 h-12 mx-auto mb-3 bg-slate-100 dark:bg-slate-800 rounded-xl flex items-center justify-center">
            <FileText className="w-6 h-6 text-slate-400 dark:text-slate-500" />
          </div>
          <p className="text-sm font-medium text-slate-500 dark:text-slate-400">Chưa có tài liệu</p>
          <p className="text-xs text-slate-400 dark:text-slate-500 mt-1">Tạo tài liệu đầu tiên</p>
        </div>
      )}

      {/* New Document Modal */}
      <Modal
        isOpen={newDocModal.open}
        onClose={() => setNewDocModal({ open: false, parentId: 'root' })}
        title="Tạo tài liệu mới"
        footer={
          <>
            <Button variant="secondary" onClick={() => setNewDocModal({ open: false, parentId: 'root' })}>
              Hủy
            </Button>
            <Button onClick={handleCreateDocument}>
              Tạo
            </Button>
          </>
        }
      >
        <Input
          label="Tên tài liệu"
          value={newTitle}
          onChange={(e) => setNewTitle(e.target.value)}
          placeholder="Nhập tên tài liệu..."
          autoFocus
          onKeyDown={(e) => e.key === 'Enter' && handleCreateDocument()}
        />
      </Modal>

      {/* New Folder Modal */}
      <Modal
        isOpen={newFolderModal.open}
        onClose={() => setNewFolderModal({ open: false, parentId: 'root' })}
        title="Tạo thư mục mới"
        footer={
          <>
            <Button variant="secondary" onClick={() => setNewFolderModal({ open: false, parentId: 'root' })}>
              Hủy
            </Button>
            <Button onClick={handleCreateFolder}>
              Tạo
            </Button>
          </>
        }
      >
        <Input
          label="Tên thư mục"
          value={newTitle}
          onChange={(e) => setNewTitle(e.target.value)}
          placeholder="Nhập tên thư mục..."
          autoFocus
          onKeyDown={(e) => e.key === 'Enter' && handleCreateFolder()}
        />
      </Modal>

      {/* Delete Confirmation Modal */}
      <Modal
        isOpen={deleteModal.open}
        onClose={() => setDeleteModal({ open: false, node: null })}
        title="Xác nhận xóa"
        footer={
          <>
            <Button variant="secondary" onClick={() => setDeleteModal({ open: false, node: null })}>
              Hủy
            </Button>
            <Button variant="danger" onClick={handleDelete}>
              Xóa
            </Button>
          </>
        }
      >
        <p className="text-slate-600 dark:text-slate-300">
          Bạn có chắc muốn xóa "{deleteModal.node?.title}"?
          {deleteModal.node?.type === 'folder' && (
            <span className="block mt-2 text-sm text-rose-600 dark:text-rose-400">
              Tất cả tài liệu trong thư mục cũng sẽ bị xóa!
            </span>
          )}
        </p>
      </Modal>
    </div>
  );
}

export default TreeView;
